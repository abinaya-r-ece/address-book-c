#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include <ctype.h>

int global_array[100]; // Array to store matched contact index during search
int gcount = 0;  //Count of matched contacts

// Function to validate name
int validate_name(char *name)
{
    int len=strlen(name); //To get length of name
                                                                                //To get lenght of name

    if (len<3) //Name must have at least 3 characters                                                                                         //Name must have atleast 3 characters
    {
        return 0;
    }
    for(int i=0;i<len;i++)
    {
        if(!isalpha(name[i])) //Only alphabets allowed                                                                                       //Alphabets only allowed                     
        {
        return 0;
        }

    }
    return 1;
}

// Function to validate phone number

int validate_phone(char *phone,AddressBook *addressBook)
{
    if(strlen(phone)!=10) //Must be 10 digits
    {
        return 0;
    }
    if(phone[0]<'6' || phone[0]>'9') //To check start digit
    {
        return 0;
    }
    for(int i=0;phone[i]!='\0';i++)
    {
        if(!isdigit(phone[i]))  //To check all digit
        {
            return 0;
        }
    }
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(strcmp(phone,addressBook->contacts[i].phone)==0) //For duplicate check
        {
            return 0;
        }
    }
    return 1;
}

// Function to validate email

int validate_email(char *email,AddressBook *addressBook)
{
    int at_pos=-1;
    int dot_pos=-1;
    int at_count=0;
    int len=strlen(email);

    if (isdigit(email[0])) //First character should not be digit
    {
        return 0;
    }

    for (int i=0;i<addressBook->contactCount;i++)
    {
        //Check duplicate email
        if (strcmp(addressBook->contacts[i].email,email)==0)
        {
            return 0;
        }
    }

    for (int i=0;i<len;i++)
    {
        //Only allowed symbols are @ and
        if (!isalnum(email[i]) && email[i] != '@' && email[i] != '.')
        {
            return 0;
        }

        if (email[i] == '@')
        {
            at_count++;
            at_pos = i;
        }

        if (email[i] == '.')
        {
            dot_pos = i;
        }

        if (isupper(email[i])) //Uppercase not allowed
        {
            return 0;
        }
    }

    if (at_count != 1) //Only one @ should be present
    {
        return 0;
    }

    if (at_pos == 0) //@ should not be first
    {
        return 0;
    }

    if (dot_pos == -1 || dot_pos < at_pos + 2) //must be present and after @
    {
        return 0;
    }

    if (dot_pos != len - 4) //After . nothing extra allowed
    {
        return 0;
    }

    for (int i = at_pos + 1; i < dot_pos; i++)
    {
        if (!isalpha(email[i])) //After @ and before . only alphabets
        {
            return 0;
        }
    }

    return 1;
}
void createContact(AddressBook *addressBook)
{
    if(addressBook->contactCount>=100) // Check if address book is already full
    {
        printf("Address book is full\n");
        return;
    }

    char name[25], phone[25], email[25];  
    int attempts=0;
//VALIDATION FOR NAME

    while(attempts<3)
    {
        printf("Enter Name : ");
        scanf(" %[^\n]", name);

        if(validate_name(name))  //Validate name using validate_name function
        {
            //Copy valid name to structure
            strcpy(addressBook->contacts[addressBook->contactCount].name, name);
            break;
        }
        else
        {
            printf("Invalid name\n"); //Invalid name entered
            attempts++;
        }
    }

    if(attempts==3) //Exit if maximum attempts reached for name
    {
        return;
    }

//VALIDATION FOR MOBILE

    attempts=0;
    while(attempts<3)
    {
        printf("Enter Phone No : ");
        scanf(" %[^\n]", phone);

        //Validate phone number using validate_phone function & check for duplicates
        if(validate_phone(phone, addressBook)) 
        {
            //Copy valid phone number to structure
            strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
            break;
        }
        else
        {
            printf("Invalid phone number\n"); //Invalid phone number entered
            attempts++;
        }
    }

    if(attempts==3) //Exit if maximum attempts reached for phone number
    {
        return;
    }
//VALIDATION FOR EMAIL

    attempts=0;
    while(attempts<3)
    {
        printf("Enter Email : ");
        scanf(" %[^\n]",email);
    
        //Validate email using validate_email function & check for duplicates
        if(validate_email(email,addressBook))
        {
            //Copy valid email to structure
            strcpy(addressBook->contacts[addressBook->contactCount].email,email);
            break;
        }
        else
        {
            printf("Invalid email\n"); //Invalid email entered
            attempts++;
        }
    }

    if(attempts==3) //Exit if maximum attempts reached for email
    {
        return;
    }
         
    printf("CONTACT CREATED SUCCESSFULLY!\n"); //COntact successfully created
    addressBook->contactCount++; //Increment contact count
    
}

void listContacts(AddressBook *addressBook) 
{
    // Sort contacts based on the chosen criteria

    if(addressBook->contactCount==0) //Check whether the address book is empty
    {
        printf("Invalid...Contact Not Found!\n"); //Print message if no contacts are found
        return ;
    }

    for(int i=0;i<addressBook->contactCount;i++)
    {
        printf("Name : %s | ",addressBook->contacts[i].name); // Display name
        printf("Phone : %s | ",addressBook->contacts[i].phone); // Display phone number
        printf("Email : %s ",addressBook->contacts[i].email); // Display email
        printf("\n"); //Move to next line
    }
    
}

void initialize(AddressBook *addressBook) 
{
    addressBook->contactCount = 0; //Initialize contact count to zero
    loadContactsFromFile(addressBook); //Load existing contacts from file into address book
}

void saveAndExit(AddressBook *addressBook) 
{
    
    saveContactsToFile(addressBook); // Save contacts to file
    exit(EXIT_SUCCESS); // Exit the program
}

int searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
    gcount=0; //Reset global match count
    int option;
    printf("\nSearch by:\n1. Name\n2. Phone\n3. Email\n"); //Display search options
    printf("Enter option : ");
    scanf("%d", &option);

    switch(option)
    {
        case 1:
        {
            //Search contact by name
            char name[100];
            printf("Enter Name: ");
            scanf(" %[^\n]", name);
            for(int i = 0; i < addressBook->contactCount; i++)
            {
                //Compare entered name with stored contacts name
                if(strcmp(addressBook->contacts[i].name, name) == 0)
                {
                    global_array[gcount++] = i; //store matched index in global array
                }
            }
            break; //break is used to terminate the current loop
        }
        case 2:
        {
            //Search contact by phone number
            char phone[100];
            printf("Enter Phone: ");
            scanf(" %[^\n]", phone);
            for(int i = 0; i < addressBook->contactCount; i++)
            {
                //Compare entered phone number with stored contacts phone number
                if(strcmp(addressBook->contacts[i].phone, phone) == 0)
                {
                    global_array[gcount++] = i; //store matched index in global array
                }
            }
            break; //break is used to terminate the current loop
        }
        case 3:
        {
            //Search contact by email
            char email[100];
            printf("Enter Email: ");
            scanf(" %[^\n]", email);
            for(int i = 0; i < addressBook->contactCount; i++)
            {
                //Compare entered email with stored contacts email
                if(strcmp(addressBook->contacts[i].email, email) == 0)
                {
                    global_array[gcount++] = i; //store matched index in global array
                }
            }
            break; //break is used to terminate the current loop
        }
        default:
            printf("Invalid option...Contact not found!\n"); //Invalid search option
    }

    if (gcount == 0) //If no contacts matched
    {
        printf("Contact not found\n");
        return 0;
    }

    printf("\nMatched Contacts:\n"); //Display all the matched contacts
    for (int i = 0; i < gcount; i++)
    {
        int idx = global_array[i]; //Stores the index of the matched contact
        printf("%d. %s | %s | %s\n",i + 1,addressBook->contacts[idx].name,addressBook->contacts[idx].phone,addressBook->contacts[idx].email);
    }

    return gcount; //Return number of matched contacts
}

void editContact(AddressBook *addressBook)
{
	/* Define the logic for Editcontact */
    
    if(addressBook->contactCount == 0)  //To check if there are any contacts to edit
    {
        printf("No Contacts Available!\n");
        return;
    }

    searchContact(addressBook); //Calling searchContact function to search contact for edit
    if(gcount==0) //Exit if no matching contacts
    {
        return;
    }

    int size; 
    printf("\nEnter the contact to be edited : ");
    scanf("%d",&size);
    if(size<1||size>gcount) //Validate selected contact number
    {
        printf("Invalid choice\n");
        return;
    }
    int index=global_array[size-1]; //Get index to select contact 
    //To display edit options
    int choice;
    printf("Edit Option : \n"); 
    printf("1.By name\n2.By phone\n3.By Email\n4.Edit  all\n5.Exit\n");
    printf("Enter choice : ");
    scanf("%d",&choice);

    char new_name[100],new_phone[11],new_email[100]; //Variables to store new values
    switch(choice)
    {
        case 1:
        {
            //Edit by contact name
            while(1)
            {
                printf("Enter new name : ");
                scanf(" %[^\n]",new_name);
                if(validate_name(new_name)) //Valid new name
                {
                    //Copy the new name to the contact
                    strcpy(addressBook->contacts[index].name,new_name);
                    break;
                }
                else
                {
                    printf("Invalid input\n"); //Invalid contact name
                }
            }
            break;
        }

        case 2:
        {
            //Edit by contact phone number
            while(1)
            {
                printf("Enter new number : ");
                scanf(" %[^\n]",new_phone);
                if(validate_phone(new_phone,addressBook)) //Valid new phone number
                {
                    //Copy the new phone number to the contact
                    strcpy(addressBook->contacts[index].phone,new_phone);
                    break;
                }
                else
                {
                    printf("Invalid input\n"); //Invalid phone number
                }
            }
            break;
        }

        case 3:
        {
            //Edit by contact email
            while(1)
            {
                printf("Enter new Email : ");
                scanf(" %[^\n]",new_email);
                if(validate_email(new_email,addressBook)) //Valid new email
                {
                     //Copy the new email to the contact
                    strcpy(addressBook->contacts[index].email,new_email);
                    break;
                }
                else
                {
                    printf("Invalid input\n"); //Invalid email
                }
            }
            break;
        }

        case 4:
        {
            //Edit by all contact details
            while(1)
            {
                printf("Enter new name : ");
                scanf(" %[^\n]",new_name);

                printf("Enter new number : ");
                scanf(" %[^\n]",new_phone);

                printf("Enter new Email : ");
                scanf(" %[^\n]",new_email);

                if(validate_name(new_name)&&validate_phone(new_phone,addressBook)&&validate_email(new_email,addressBook))
                {
                    strcpy(addressBook->contacts[index].name,new_name); //Updtae new name
                    strcpy(addressBook->contacts[index].phone,new_phone); //Update new phone number
                    strcpy(addressBook->contacts[index].email,new_email); //Update new email
                    break;
                }
                else
                {
                    printf("Invalid input\n");
                }
            }
            break;
        }
        case 5:
        {
            return; //To exit editcontcat
        }

        default :
        {
            printf("Invalid Choice\n"); //Invalid edit option
            return;
        }

    }

    
}

void deleteContact(AddressBook *addressBook)
{
	/* Define the logic for deletecontact */

    if(addressBook->contactCount == 0)  //To check if there are any contacts to delete
    {
        printf("No Contacts Available!\n");
        return;
    }
    searchContact(addressBook); //Calling searchContact function to search contact for delete

    if(gcount==0) //Exit if no matching contacts
    {
        return;
    }

    int si; //Variable to store serial number
    printf("Enter the contact to delete: ");
    scanf("%d",&si);

    if(si<1||si>gcount) //Validate contact number for selected
    {
        printf("Invalid choice\n");
        return;
    }

    int index=global_array[si-1];//Get index to select contact

    for(int i=index;i<addressBook->contactCount-1;i++)
    {
        addressBook->contacts[i] = addressBook->contacts[i + 1]; //Overwrite deleted contact
    }

    addressBook->contactCount--; //Decrease total contact count
    printf("Contact Deleted Successfully!\n");
}
