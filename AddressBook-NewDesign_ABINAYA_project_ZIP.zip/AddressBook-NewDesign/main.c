/*
NAME: ABINAYA R 
class: 25036A
DESCRIPTION: 
The Address Book project is a C program used to store and manage contact details like name, mobile number, and email ID.
In this we can create,search,edit,list and delete the contact.
sample output:

Address Book Menu:
1. Create contact
2. Search contact
3. Edit contact
4. Delete contact
5. List all contacts
6. Save and Exit

Enter your choice: 1
Enter name:
abitha
Mobile number:
6380391589
Email ID:
abi04@gmail.com
Contact added successfully!

Enter your choice: 2
Search by:
1. Name
2. Phone
3. Email
Enter your choice: 1
search: parkavi
Contact Found
1. parkavi | 9944435611 | parkavi@gmail.com

Enter your choice: 3
Name to edit: abi
1. Edit Name
2. Edit Phone
3. Edit Email
4. Edit All
5. Exit
Enter your choice: 1
Enter new name: abinaya
Name updated successfully.

Enter your choice: 4
Enter the contact to delete: parkavi
Contact deleted successfully.

Enter your choice: 5
Name         :priya
Mobile number:8907162543
Email ID     :priya@gmail.com
Name         :karthika
Mobile number:8129605427
Email ID     :karthika@gmail.com
Name         :abinaya
Mobile number:9087654321
Email ID     :abinaya@gmail.com
*/

#include <stdio.h>
#include "contact.h"

int main() 
{
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book

    do 
    {
        printf("\nAddress Book Menu:\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
    	printf("6. Save and Exit\n");		
        // printf("7. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        
        switch (choice) 
        {
            case 1:
                createContact(&addressBook);
                break;
            case 2:
                searchContact(&addressBook);
                break;
            case 3:
                editContact(&addressBook);
                break;
            case 4:
                deleteContact(&addressBook);
                break;
            case 5:          
                listContacts(&addressBook);
                break;
            case 6:
                printf("Saving and Exiting...\n");
                saveContactsToFile(&addressBook);
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);
    
    return 0;
}
